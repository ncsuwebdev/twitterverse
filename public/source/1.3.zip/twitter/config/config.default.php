<?php 

return array(
    'oauth' => array(
        'consumerKey' => '',
        'consumerSecret' => '',
        'token' => '',
        'tokenSecret' => '',
    ),
    'site' => array(
        'url' => '',
    ),
    'feed' => array(
        'title' => '',
        'author' => '',
    ),
);