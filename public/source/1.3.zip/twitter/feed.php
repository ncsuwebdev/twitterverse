<?php 
require_once 'inc/Tweets/Display.php';

Tweets_Display::feed();